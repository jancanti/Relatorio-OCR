/**
 * 
 */
package br.com.deployxtech.ocr;

import java.util.List;

/**
 * @author Daniel Jan�anti
 *
 */
public interface Classification {
	CharacterImage analyze(CharacterImage character);
	List<CharacterImage> getCharacters();
}